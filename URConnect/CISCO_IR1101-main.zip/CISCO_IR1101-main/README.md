# Python ModbusTCP
  
  Read ModbusTCP from URConnect 
  
  - Add Register Address
  - IP Slave
  - ClientID
  - Token

### Running

$python [File Name.py] 
